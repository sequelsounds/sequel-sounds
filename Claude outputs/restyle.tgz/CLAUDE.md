# CLAUDE.md

Working notes for Claude in this repo. Read `docs/overview.md` first for what
the product is, `docs/product-spec.md` for what is being built, and
`docs/mockups/sequel-studio-mockup.html` for what the staff app looks like;
this file is about how to work here.

**The Sequel Track rebuild notes are NOT in this repo.** They live in the
claude.ai Project "Sequel App", deliberately — they are about Track, which is
being replaced, and they die with it. Read them from there with the Projects
tool, not from disk:

- `claude/sequel-track-supabase-migration.md` — the cold-start brief: what is
  built, what the mirror views are, and the traps that have cost time. Read
  this first for anything touching Track's data.
- `claude/sequel-track-known-issues.md` — what is broken, in which stack, and
  what is waiting on a decision.

The same Project holds the per-page and per-endpoint notes for Track itself
(Xano, Wized, Webflow), which are the spec for anything still being copied.

## Commands

```bash
npm run dev     # Vite dev server on :5173 (not pinned — see gotchas)
npm run build   # tsc -b && vite build
npm run lint    # oxlint
npm run types   # regenerate src/lib/database.types.ts (needs the supabase CLI)
```

**Type-check with `npx tsc -b`.** ⚠️ `npx tsc --noEmit -p .` checks NOTHING here —
the root tsconfig only holds project references — and exits 0 whatever the
code says. It was used for a whole session on 15 Sep 2026 and hid real errors.
Proven: a deliberate type error fails `tsc -b` and passes the other.

There is **no Prettier config**, but the codebase is Prettier-formatted with
`--no-semi --single-quote`. Match it. If a scripted edit disturbs formatting,
reformat with exactly those flags rather than hand-fixing indentation.

The `supabase` CLI is **not installed** on this machine. `npm run types` will
fail; patch `src/lib/database.types.ts` by hand after a migration and keep it
alphabetical, the way the generator emits it.

## Before you change anything

- **Read the live database, not just the migrations.** They have matched so far,
  but the Supabase MCP can query `sveirphsppyfhulymjiu` directly and that is the
  truth. Several "bugs" this session were data, not code — a string in
  `projects_mirror.client_name`, not a hardcoded label.
- **Read the Webflow site for anything visual.** Brand values are not guesses:
  the site at `sequelsounds.app` (id `68e6c2e8dbcd39de2547a97d`) is queryable,
  and computed styles off the live page settle colour, spacing and type
  questions exactly. See `docs/decisions.md`.
- **Resolve the variables, do not infer them.** A Webflow style returns a
  colour as `{"id": "variable-…"}`, not a value. Look it up with
  `data_variable_tool`. Guessing what a variable "must" be is how the nav
  ended up documented as silver-on-dark when it is Sequel Brown on Sequel
  Silver — and the wrong guess then sat in two files for hours.

## Conventions

- Tailwind v4. Design tokens live in `@theme` in `src/index.css`; brand colours
  are `sequel-brown`, `sequel-silver`, `sequel-asphalt`, `sequel-error`. **No
  `neutral-*` classes, and no Tailwind `red-*`** — both are cool on a warm
  palette and read as washed out or foreign.
- **Build pages from `src/styles/design-system.css`**, not from ad-hoc
  utilities: `.surface-dark` / `.surface-light`, `.display-heading`,
  `.field-label`, `.field-underline` / `.field-boxed`, `.corner-note`,
  `.form-error`, and `.btn` plus a language (`.btn-wide` for landing pages,
  `.btn-mono` for the tool) and a colour (`.btn-light`, `.btn-dark`,
  `.btn-outline`). Add to that file rather than restating values in a route.
- **Zero border radius.** The whole radius scale is zeroed in `@theme` and there
  are no `rounded*` classes in markup. Both, deliberately — see gotchas.
- **Never fade text** with `opacity` or a translucent colour to make it
  secondary (Andy, 16 Sep 2026: "lazy design … I don't ever want to see it").
  Text is solid; hierarchy comes from size, weight, case and spacing.
- Fonts are self-hosted in `public/fonts/`, never linked from a CDN. All use
  `font-display: block`, and the above-the-fold faces are preloaded in
  `index.html`.
- Comments explain *why*, not what. Match the density already in `src/lib/`.

## Things that are easy to get wrong

- **Partners never fill in forms.** The inbox page takes a name/email/company
  once per browser and nothing else. Do not add per-track fields; staff edit
  metadata from the "i" button on a track row.
- **Staff upload too.** `sign-upload` takes either an inbox token or a staff
  session; the staff path names the project explicitly. Dropping files on the
  Playlist Creator uploads them and adds them to the playlist. `purpose:
  'artwork'` is the third mode — staff only, images only, and it mints a fresh
  `artwork-<uuid>.<ext>` rather than overwriting the Lambda's `artwork.jpg`,
  because reads are presigned and cached for an hour.
- **Library tags are the library's, not ours.** Production libraries write
  `TITLE --- sales copy` into the title frame and dump keywords into the
  comment. Nothing in the pipeline rewrites that; DISCO does not either.
  Staff fix it from the "i" button.
- **Video artwork is a frame at one second.** Measured, not documented: the
  Lambda grabs t=1.000 exactly and scales it to 1066x600. Audio gets an
  `artwork.jpg` only if the file carries embedded cover art. So a film that
  fades up from black gets a black cover — one of six test uploads did, a
  4KB JPEG with a mean brightness of 0, picture arriving by t=2. Worth
  switching to ffmpeg's `thumbnail` filter next time the Lambda is open.
- **A link's kind decides its page.** `playlists.kind` is standard / sync /
  composition; `src/routes/SharedPlaylist.tsx` picks the page. A
  composition review always requires sign-in — a check constraint, so an
  update that sets `kind = 'composition'` must set `require_sign_in` in the
  same statement. `sign-media` enforces the two download switches; do not
  add a download the page decides on its own.
- **The viewer page has its own client and player.** `lib/viewer.ts` and
  `lib/viewerPlayer.tsx`, not `lib/queries.ts` and `lib/player.tsx`: token
  in a header, the app's session as bearer, only the columns a client
  should see (`VIEWER_TRACK_COLS`). Never widen that list with submitter or
  staff fields.
- **Browser-side metadata is a first pass.** The Lambda re-reads tags server-side
  and is authoritative. Never make an upload depend on a browser tag read.
- **Nothing blocks an upload on a guess.** Duplicate detection is advisory at
  every layer. Losing a track that belonged is worse than storing it twice.
- **Never commit font files you have not licensed**, and never write secret
  values into the repo or into error messages. `sign-upload` reports secret
  *names and lengths* only, on purpose.

## Verifying work

Prefer checking the running app over asserting it works. The in-app browser can
drive `localhost:5173`, and reading computed styles or the DOM beats reasoning
about CSS. Staff sign-in needs an emailed code you cannot receive, so for the
staff shell use **`/__preview/projects/p1`** — a dev-only route that mounts the
real components over fixture data (`src/dev/Preview.tsx`). It is compiled out
of production builds. When testing uploads, clean up afterwards: delete both the `tracks`
row and the S3 object.

**The preview is fixtures over the real client.** `/__preview` mounts the
real components with seeded query data, but `supabase` is the same client
the app uses — so a mutation fired from that route reaches the live
database. Creating a playlist there creates a playlist. Use the real routes
for anything you mean to keep, and treat `/__preview` as somewhere to look
at components rather than exercise them. The route no longer *refetches*
after a write — its fixture ids (`p1`, `t1`) are not uuids, and an
invalidation used to send them to Postgres and come back with `invalid
input syntax for type uuid` — but writes still go out.

The viewer page can be looked at live without a sign-in: any playlist with
*Sign-in required* off resolves at `/p/<token>`, and the tokens are in the
`playlists` table. The sync session and composition pages need a playlist
of that kind; make a throwaway one by SQL and delete it after.

`:focus-visible` does not match a programmatic `.focus()` — only real keyboard
interaction. Test focus styles by sending Tab keypresses.

## Deployment

The app is a static build on **Cloudflare Workers** (`wrangler.jsonc`, assets
from `./dist`, SPA not-found handling). It runs at
**https://studio.sequelsounds.com** today; its intended home is
**https://app.sequelsounds.com** (Andy, 13 and 15 Sep 2026) — everything on the
old app and the audio side ends up there. short.io still holds
`app.sequelsounds.com` until its links expire on 19 Sep, so the move is after
that. Both origins are allowed everywhere below; keep it that way until
`studio.` is retired.

`VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY` are **build-time**
variables — Vite inlines them, so they belong in Cloudflare's build environment,
not as Worker secrets. Set as Worker secrets they do nothing and the app throws
`Missing VITE_SUPABASE_URL` on load.

**A new origin has to be added in four places, or uploads fail in ways that
look unrelated:**

1. `ALLOWED_ORIGINS` in every edge function the browser calls —
   `sign-upload`, `sign-media`, `sign-document`, `delete-track` and
   `quickbooks` — then redeploy each
2. the S3 bucket CORS — `infra/s3-cors.json`, applied with
   `aws s3api put-bucket-cors --bucket sequel-sounds-media --region eu-west-2
   --cors-configuration file://infra/s3-cors.json`
3. `APP_BASE_URL` in the Supabase secrets, which is what `xano-webhook` uses to
   build the inbox links Xano stores — change this only when the app is
   actually served from the new origin, or every new link points nowhere

Miss (1) and the presign call is blocked — or, for `sign-media`, every artwork
and preview in the staff app silently fails to load; miss (2) and the presign succeeds but
the PUT to S3 is blocked — the page looks fine until someone actually drops a
file. Miss (3) and every partner link Xano hands out points at the wrong host.

The Edge Functions' IAM key was provisioned for **presigning**, which only
ever names one key at a time — so it has no `s3:ListBucket` and no
`s3:DeleteObject`. `delete-track` needs both, and fails with
`list failed (403)` without them. The statement to add is
`infra/s3-list-policy.json`; note that `ListBucket` is granted on the
**bucket** arn, not on `bucket/*`, which is the usual way to get this wrong.

Edge Functions deploy separately from the app; editing a file under
`supabase/functions/` changes nothing until it is deployed. There is no supabase
CLI on this machine, but the Supabase MCP can deploy — keep `verify_jwt` as it
was (`true` for `sign-upload`, `sign-media`, `sign-document` and `delete-track`;
`false` for `xano-webhook`, `xano-mirror-sync` and `track-processed`, which
authenticate themselves with a shared secret, and for `quickbooks` and
`qbo-callback`, which check finance and the OAuth state themselves).

